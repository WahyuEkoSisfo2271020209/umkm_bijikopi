<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php?Home=2"); // Arahkan ke login jika belum login
    exit;
}
?>

<section style="padding: 2rem;">
  <h2>Manajemen Produk</h2>
  <p>Selamat datang <strong><?= $_SESSION['username'] ?></strong>. Anda dapat mengelola produk kopi di sini.</p>
</section>
