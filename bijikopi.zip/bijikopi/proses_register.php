<?php
session_start();
include "koneksi.php";

$username = trim($_POST['username']);
$password = trim($_POST['password']);

// Validasi sederhana
if (strlen($username) < 3 || strlen($password) < 4) {
    echo "<p style='color:red;text-align:center;'>Username dan password terlalu pendek.</p>";
    echo "<p style='text-align:center;'><a href='register.php'>Kembali</a></p>";
    exit;
}

// Hash password
$hashed = password_hash($password, PASSWORD_DEFAULT);

// Simpan ke database
$stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $username, $hashed);

if ($stmt->execute()) {
    echo "<p style='color:green;text-align:center;'>Akun berhasil dibuat! Silakan <a href='index.php?Home=2'>login</a>.</p>";
} else {
    echo "<p style='color:red;text-align:center;'>Username sudah digunakan. Silakan coba yang lain.</p>";
    echo "<p style='text-align:center;'><a href='register.php'>Kembali</a></p>";
}
?>
