<?php
// Ambil data dari POST
$nama_produk = $_POST['nama'] ?? '';
$harga = $_POST['harga'] ?? 0;
$jumlah = $_POST['jumlah'] ?? 1;
$total = $harga * $jumlah;

// Daftar gambar berdasarkan nama produk
$gambar_produk = [
  "Kopi Robusta Lampung" => "kopi_robusta.jpg",
  "Kopi Arabika Lampung" => "kopi_arabika.jpg",
  "Kopi Liberika Lampung" => "kopi_liberika.jpg"
];

$gambar = $gambar_produk[$nama_produk] ?? 'default.jpg';
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Checkout</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f8f2e9;
      margin: 0;
      padding: 0;
    }

    .checkout-container {
      max-width: 600px;
      margin: 3rem auto;
      background-color: #fffaf0;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }

    .checkout-container img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-radius: 10px;
      margin-bottom: 1rem;
    }

    h2 {
      text-align: center;
      color: #3a2c1a;
      margin-bottom: 1rem;
    }

    .checkout-box {
      margin-bottom: 2rem;
    }

    .checkout-box p {
      margin: 0.5rem 0;
      font-size: 1rem;
    }

    .form-checkout label {
      display: block;
      margin-top: 1rem;
      font-weight: bold;
    }

    .form-checkout input,
    .form-checkout textarea,
    .form-checkout select {
      width: 100%;
      padding: 8px;
      margin-top: 4px;
      border-radius: 6px;
      border: 1px solid #ccc;
      font-size: 1rem;
      font-family: 'Inter', sans-serif;
      background-color: #fff;
    }

    .form-checkout button {
      margin-top: 1.5rem;
      background-color: #5c3a1c;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 8px;
      cursor: pointer;
      width: 100%;
    }

    .form-checkout button:hover {
      background-color: #44290d;
    }
  </style>
</head>
<body>
  <div class="checkout-container">
    <img src="img/<?= htmlspecialchars($gambar) ?>" alt="Foto <?= htmlspecialchars($nama_produk) ?>">

    <h2>Checkout</h2>

    <div class="checkout-box">
      <p><strong>Produk:</strong> <?= htmlspecialchars($nama_produk) ?></p>
      <p><strong>Harga:</strong> Rp <?= number_format($harga, 0, ',', '.') ?></p>
      <p><strong>Jumlah:</strong> <?= htmlspecialchars($jumlah) ?> kg</p>
      <p><strong>Total:</strong> <strong>Rp <?= number_format($total, 0, ',', '.') ?></strong></p>
    </div>

    <form class="form-checkout" action="proses_pesanan.php" method="post">
      <!-- Data tersembunyi untuk diproses -->
      <input type="hidden" name="nama" value="<?= htmlspecialchars($nama_produk) ?>">
      <input type="hidden" name="harga" value="<?= htmlspecialchars($harga) ?>">
      <input type="hidden" name="jumlah" value="<?= htmlspecialchars($jumlah) ?>">
      <input type="hidden" name="total" value="<?= htmlspecialchars($total) ?>">
      <input type="hidden" name="gambar" value="<?= htmlspecialchars($gambar) ?>">

      <!-- Data pembeli -->
      <label for="nama_pembeli">Nama Lengkap</label>
      <input type="text" id="nama_pembeli" name="nama_pembeli" required>

      <label for="alamat">Alamat Pengiriman</label>
      <textarea id="alamat" name="alamat" rows="4" required></textarea>

      <label for="telepon">Nomor Telepon</label>
      <input type="text" id="telepon" name="telepon" required>

      <label for="metode_pembayaran">Metode Pembayaran</label>
      <select id="metode_pembayaran" name="metode_pembayaran" required>
        <option value="">-- Pilih Metode --</option>
        <option value="Transfer Bank">Transfer Bank</option>
        <option value="COD">Bayar di Tempat (COD)</option>
        <option value="E-Wallet">E-Wallet</option>
      </select>

      <button type="submit">pesan</button>
    </form>
  </div>
</body>
</html>
