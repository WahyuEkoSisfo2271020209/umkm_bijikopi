<section class="hero">
  <div class="hero-content">
    <h1>Rasakan Aroma Khas<br>Biji Kopi Asli Lampung</h1>
    <div class="buttons">
      <button>Kopi Robusta</button>
      <button>Kopi Arabika</button>
      <button>Kopi Liberika</button>
    </div>
    <div class="buttons">
       <a href="index.php?Home=1"><button>Lihat Produk</button></a>
    </div>
  </div>
</section>
