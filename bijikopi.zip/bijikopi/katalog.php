<h2 style="text-align:center; margin-top: 1rem;">Katalog Produk</h2>
<div class="product-list">
  <?php
  $produk = [
    [
      "nama" => "Kopi Robusta Lampung",
      "deskripsi" => "Biji kopi robusta asli Lampung yang berkualitas",
      "harga" => 50000,
      "gambar" => "kopi_robusta.jpg"
    ],
    [
      "nama" => "Kopi Arabika Lampung",
      "deskripsi" => "Biji kopi arabika asli Lampung yang bercita rasa",
      "harga" => 70000,
      "gambar" => "kopi_arabika.jpg"
    ],
    [
      "nama" => "Kopi Liberika Lampung",
      "deskripsi" => "Biji kopi liberika asli Lampung yang langka",
      "harga" => 90000,
      "gambar" => "kopi_liberika.jpg"
    ]
  ];

  foreach ($produk as $item) {
    echo '
    <div class="product-item">
      <img src="img/'.$item["gambar"].'" alt="'.$item["nama"].'">
      <div class="product-info">
        <h3>'.$item["nama"].'</h3>
        <p>'.$item["deskripsi"].'</p>
        <form action="index.php?Home=5" method="post">
          <input type="hidden" name="nama" value="'.$item["nama"].'">
          <input type="hidden" name="harga" value="'.$item["harga"].'">
          <label for="jumlah">Jumlah (kg):</label>
          <input type="number" id="jumlah" name="jumlah" min="1" value="1" required>
          <p class="harga">Rp '.number_format($item["harga"], 0, ',', '.').'</p>
          <button type="submit">Checkout</button>
        </form>
      </div>
    </div>';
  }
  ?>
</div>
