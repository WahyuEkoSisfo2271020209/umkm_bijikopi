<body>
    <div class="container">
        <main class="content">
            <!-- Konten utama halaman -->
        </main>
        
        <div class="footer-links">
            <div class="footer-links a">
            
                    <a href="#">Tentang Kami</a>
                    <a href="#">Kontak</a>
            
            </div>
        </div>

        <footer>
            &copy; UMKM Kopi Lampung 2025 – All rights reserved
        </footer>
    </div>
</body>
</html>