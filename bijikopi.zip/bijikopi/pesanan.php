<?php
include 'koneksi.php';

$result = $conn->query("SELECT * FROM pesanan ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Pesanan</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f2e9;
        }
        h2 {
            text-align: center;
            margin-top: 2rem;
        }
        table {
            margin: auto;
            background: #fff;
            border-collapse: collapse;
            width: 95%;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
            vertical-align: middle;
        }
        th {
            background-color: #f0e4cd;
        }
        img.produk-img {
            max-width: 100px;
            height: auto;
            border-radius: 6px;
        }
    </style>
</head>
<body>
<h2>Daftar Pesanan</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Produk</th>
        <th>Gambar</th>
        <th>Harga/kg</th>
        <th>Jumlah (kg)</th>
        <th>Total</th>
        <th>Nama Pembeli</th>
        <th>Alamat</th>
        <th>No HP</th>
        <th>Metode Pembayaran</th>
        <th>Tanggal Pesan</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['nama_produk'] ?></td>
        <td>
            <img src="img/<?= htmlspecialchars($row['gambar']) ?>" alt="<?= $row['nama_produk'] ?>" class="produk-img">
        </td>
        <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
        <td><?= $row['jumlah'] ?></td>
        <td>Rp <?= number_format($row['total'], 0, ',', '.') ?></td>
        <td><?= $row['nama_pembeli'] ?></td>
        <td><?= $row['alamat'] ?></td>
        <td><?= $row['telepon'] ?></td>
        <td><?= $row['metode_pembayaran'] ?></td>
        <td><?= $row['tanggal_pesan'] ?></td>
    </tr>
    <?php endwhile; ?>
</table>
</body>
</html>
