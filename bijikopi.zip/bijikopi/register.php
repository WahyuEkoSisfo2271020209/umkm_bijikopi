<?php

?>

<section style="padding: 2rem; max-width: 500px; margin: auto;">
  <h2>Daftar Akun Baru</h2>
  <form action="proses_register.php" method="post">
    <label>Username:</label><br>
    <input type="text" name="username" required><br><br>
    <label>Password:</label><br>
    <input type="password" name="password" required><br><br>
    <button type="submit">Daftar</button>
  </form>
  <p style="margin-top: 1rem;">Sudah punya akun? <a href="index.php?Home=2">Login di sini</a></p>
</section>